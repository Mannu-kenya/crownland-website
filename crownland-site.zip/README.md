# Crownland Security & Insurance Investigators (K) Ltd

Company website. A single self-contained page: `index.html` (photos, videos and styles are built in).

## Publish with GitHub Pages
1. Open the repository on GitHub, then Settings > Pages.
2. Under "Build and deployment", choose "Deploy from a branch", branch `main`, folder `/ (root)`, and Save.
3. After a minute the site is live at `https://<your-username>.github.io/<repository-name>/`.
4. To use your own domain, add it under "Custom domain" on the same page.
